# $Id: $
#
# osCommerce, Open Source E-Commerce Solutions
# http://www.oscommerce.com
#
# Copyright (c) 2007 osCommerce
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License v2 (1991)
# as published by the Free Software Foundation.

images_resize_title = Resize Images
images_resize_table_heading_groups = Groups
images_resize_table_heading_total_resized = Total Resized
images_resize_field_groups = Groups:
images_resize_field_overwrite_images = Overwrite Existing Images?
