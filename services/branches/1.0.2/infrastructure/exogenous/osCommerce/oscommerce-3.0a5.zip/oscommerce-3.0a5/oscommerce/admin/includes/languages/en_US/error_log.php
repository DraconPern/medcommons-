# $Id$
#
# osCommerce, Open Source E-Commerce Solutions
# http://www.oscommerce.com
#
# Copyright (c) 2009 osCommerce
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License v2 (1991)
# as published by the Free Software Foundation.

heading_title = Error Log

table_heading_date = Date
table_heading_message = Message

title_delete_error_log = Delete Error Log File
introduction_delete_error_log = Please verify the removal of the error log file.
number_of_error_log_file_entries = Total error log file entries to delete: %s
