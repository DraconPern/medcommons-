<?php
/*
  $Id: $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2009 osCommerce

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License v2 (1991)
  as published by the Free Software Foundation.
*/

  class osC_Application_Index extends osC_Template_Admin {

/* Protected variables */

    protected $_module = 'index',
              $_page_title,
              $_page_contents = 'main.php';
  }
?>
