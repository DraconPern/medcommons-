# $Id: $
#
# osCommerce, Open Source E-Commerce Solutions
# http://www.oscommerce.com
#
# Copyright (c) 2007 osCommerce
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License v2 (1991)
# as published by the Free Software Foundation.

heading_title = Administrators Log

operation_title_filter_modules = Modules:
operation_title_filter_users = Users:

action_heading_batch_delete_entries = Batch Delete Administrator Log Entries

table_heading_module = Module
table_heading_id = ID
table_heading_type = Type
table_heading_user = User
table_heading_date = Date
table_heading_action = Action
table_heading_fields = Fields
table_heading_value_old = Old Value
table_heading_value_new = New Value

field_date = Date:

filter_all = -- All --

introduction_delete_entry = Please verify the removal of this administrator log entry.

introduction_batch_delete_entries = Please verify the removal of the following administrator log entries.
