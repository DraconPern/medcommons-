# $Id: $
#
# osCommerce, Open Source E-Commerce Solutions
# http://www.oscommerce.com
#
# Copyright (c) 2007 osCommerce
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License v2 (1991)
# as published by the Free Software Foundation.

heading_title = Login

action_heading_login = Log Into The Administration Tool

introduction = Please identify yourself to log into the administration tool.

field_username = Username:
field_password = Password:

ms_success_logged_out = Success: You have been successfully logged out of this system.
ms_error_login_invalid = Error: Identification of the store administrator failed. Please try again if you have been authorized to use this system.
