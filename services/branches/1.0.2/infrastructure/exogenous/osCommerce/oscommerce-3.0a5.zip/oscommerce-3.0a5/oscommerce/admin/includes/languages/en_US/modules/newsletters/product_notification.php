# $Id$
#
# osCommerce, Open Source E-Commerce Solutions
# http://www.oscommerce.com
#
# Copyright (c) 2007 osCommerce
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License v2 (1991)
# as published by the Free Software Foundation.

newsletter_product_notifications_title = Product Notifications
newsletter_product_notifications_table_heading_products = Products
newsletter_product_notifications_table_heading_selected_products = Selected Products
newsletter_product_notifications_button_global = Global
newsletter_product_notifications_button_select = &gt;&gt;&gt;
newsletter_product_notifications_button_deselect = &lt;&lt;&lt;
newsletter_product_notifications_total_recipients = Recipients receiving this newsletter: %s
newsletter_product_notifications_warning_no_products_selected = Warning: Please select one or more products.
