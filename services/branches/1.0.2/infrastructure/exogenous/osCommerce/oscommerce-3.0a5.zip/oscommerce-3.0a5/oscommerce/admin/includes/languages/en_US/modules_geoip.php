# $Id: $
#
# osCommerce, Open Source E-Commerce Solutions
# http://www.oscommerce.com
#
# Copyright (c) 2007 osCommerce
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License v2 (1991)
# as published by the Free Software Foundation.

heading_title = GeoIP Modules

table_heading_geoip_modules = GeoIP Modules
table_heading_action = Action

field_title = Title:
field_description = Description:
field_author = Author:

introduction_edit_geoip_module = Please make the necessary changes for this GeoIP module.

introduction_uninstall_geoip_module = Please verify the uninstallation of this GeoIP module.
