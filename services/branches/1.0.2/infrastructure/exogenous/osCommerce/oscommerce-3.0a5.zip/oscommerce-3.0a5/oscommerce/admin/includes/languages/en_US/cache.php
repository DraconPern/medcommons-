# $Id$
#
# osCommerce, Open Source E-Commerce Solutions
# http://www.oscommerce.com
#
# Copyright (c) 2007 osCommerce
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License v2 (1991)
# as published by the Free Software Foundation.

heading_title = Cache Control

table_heading_cache_blocks = Cache Blocks
table_heading_total = Total
table_heading_date_last_modified = Last Modified
table_heading_action = Action

cache_location = Cache Directory:

ms_error_cache_directory_non_existant = Error: The cache directory does not exist: %s
ms_error_cache_directory_not_writable = Error: The cache directory is not writable: %s
