#! /usr/bin/env python
"""WSDL parsing services package for Web Services for Python."""

ident = "$Id: __init__.py,v 1.11 2004/12/07 15:54:53 blunck2 Exp $"

import WSDLTools
import XMLname
import logging

